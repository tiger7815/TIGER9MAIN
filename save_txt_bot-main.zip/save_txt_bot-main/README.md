# txt uploader

# MADE BY MR. SATYAM


## DEPLOY TO HEROKU


[![Deploy to heroku chacha](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/tiger7815/save_txt_bot)
